package com.example.sakila;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SakilaApplicationTests {

	@Test
	void contextLoads() {
	}

}
